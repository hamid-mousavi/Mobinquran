import crypto from 'node:crypto';

interface RateLimitResult {
  allowed: boolean;
  used: number;
  limit: number;
  resetAt: number;
}

interface Counter {
  count: number;
  resetAt: number;
}

const memoryCounters = new Map<string, Counter>();

function env(name: string): string {
  return (process.env[name] || '').trim();
}

function isProduction(): boolean {
  return env('NODE_ENV') === 'production';
}

function dayWindow(): { start: number; resetAt: number } {
  const now = Date.now();
  const start = new Date(now);
  start.setUTCHours(0, 0, 0, 0);
  return { start: start.getTime(), resetAt: start.getTime() + 86_400_000 };
}

export function hashRateLimitKey(ip: string, deviceId: string): string {
  return crypto.createHash('sha256').update(`${ip}|${deviceId}`).digest('hex');
}

export async function getDailyQuotaUsage(key: string): Promise<number> {
  const storageKey = `quran-ai:${new Date().toISOString().slice(0, 10)}:${key}`;
  const url = env('UPSTASH_REDIS_REST_URL');
  const token = env('UPSTASH_REDIS_REST_TOKEN');
  if (url && token) {
    try {
      const response = await fetch(`${url}/get/${storageKey}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json() as { result?: string | number };
        return Number(data?.result || 0);
      }
    } catch {}
  }
  const counter = memoryCounters.get(storageKey);
  if (counter && counter.resetAt > Date.now()) {
    return counter.count;
  }
  return 0;
}

async function incrementUpstash(key: string, resetAt: number): Promise<number | null> {
  const url = env('UPSTASH_REDIS_REST_URL');
  const token = env('UPSTASH_REDIS_REST_TOKEN');
  if (!url || !token) return null;

  const response = await fetch(`${url}/pipeline`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify([
      ['INCR', key],
      ['EXPIREAT', key, Math.ceil(resetAt / 1000)],
    ]),
  });
  if (!response.ok) throw new Error('rate-limit store unavailable');
  const result = await response.json() as Array<{ result?: number }>;
  return Number(result?.[0]?.result || 0);
}

export async function consumeDailyQuota(key: string): Promise<RateLimitResult> {
  const limit = Math.max(1, Number(env('AI_DAILY_LIMIT') || 20));
  const { resetAt } = dayWindow();
  const allowMemoryFallback = env('ALLOW_MEMORY_RATE_LIMIT') === 'true';

  if (isProduction() && (!env('UPSTASH_REDIS_REST_URL') || !env('UPSTASH_REDIS_REST_TOKEN'))) {
    if (!allowMemoryFallback) {
      return { allowed: false, used: 0, limit, resetAt };
    }
  }

  const storageKey = `quran-ai:${new Date().toISOString().slice(0, 10)}:${key}`;

  let used: number;

  try {
    const persisted = await incrementUpstash(storageKey, resetAt);
    if (persisted !== null) {
      used = persisted;
    } else {
      if (isProduction() && !allowMemoryFallback) {
        return { allowed: false, used: 0, limit, resetAt };
      }
      const existing = memoryCounters.get(storageKey);
      const counter = existing && existing.resetAt > Date.now()
        ? existing
        : { count: 0, resetAt };
      counter.count += 1;
      memoryCounters.set(storageKey, counter);
      used = counter.count;
    }
  } catch {
    if (isProduction() && !allowMemoryFallback) {
      return { allowed: false, used: 0, limit, resetAt };
    }
    const existing = memoryCounters.get(storageKey);
    const counter = existing && existing.resetAt > Date.now()
      ? existing
      : { count: 0, resetAt };
    counter.count += 1;
    memoryCounters.set(storageKey, counter);
    used = counter.count;
  }

  return { allowed: used <= limit, used, limit, resetAt };
}
